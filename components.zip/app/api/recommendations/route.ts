import { NextResponse } from "next/server";

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }
  const baseUrl = process.env.RECOMMENDER_API_URL;
  if (!baseUrl) {
    return NextResponse.json({ error: "RECOMMENDER_API_URL is missing" }, { status: 503 });
  }
  try {
    const upstream = await fetch(`${baseUrl.replace(/\/$/, "")}/recommendations`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      cache: "no-store",
      signal: AbortSignal.timeout(120_000),
    });
    if (!upstream.ok) {
      return NextResponse.json({ error: "Recommendation request failed" }, {
        status: upstream.status === 422 ? 422 : 502,
      });
    }
    return NextResponse.json(await upstream.json());
  } catch {
    return NextResponse.json({ error: "Recommender is unavailable or timed out" }, { status: 502 });
  }
}
