import { Skeleton } from "@/components/shared/DataState";
export default function Loading() {
  return <Skeleton label="Loading recommendations and history" />;
}
