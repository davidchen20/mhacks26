/** Shared dining-hall types. Item-level waste and cost always originate here. */

export type HallId =
  | "bursley"
  | "south-quad"
  | "east-quad"
  | "mosher-jordan"
  | "markley"
  | "twigs";

export type Meal = "breakfast" | "lunch" | "brunch" | "dinner";
export type OverviewMeal = "all" | Meal;
export type Category = "Protein" | "Produce" | "Grains" | "Dairy";
export type Decision = "Accepted" | "Dismissed";
export type MenuSource = "mdining" | "sample";
export type Range = "today" | "yesterday" | "week";
export type FinancePeriod = "today" | "7" | "28";
export type WeightSource =
  | "serving-size"
  | "converted-volume"
  | "keyword-default"
  | "category-default";
export type CostSource = "item-keyword" | "category-default";

export interface Hall {
  id: HallId;
  name: string;
}

export interface NutritionAvailable {
  available: true;
  fiberGrams: number;
  proteinGrams: number;
  calories: number;
  nutrientDensity: "moderate" | "high";
  densityScore: number;
}

export interface NutritionUnavailable {
  available: false;
}

export type Nutrition = NutritionAvailable | NutritionUnavailable;

export interface ScrapedItem {
  station: string;
  name: string;
  servingSize: string | null;
  calories: number | null;
  fiberGrams: number | null;
  proteinGrams: number | null;
  traits: string[];
  allergens: string[];
}

export type ScrapedArchive = {
  [hall in HallId]?: {
    [date: string]: {
      [meal in Meal]?: ScrapedItem[];
    };
  };
};

export interface MenuItem {
  id: string;
  name: string;
  category: Category;
  remainingPct: number;
  wasteLbs: number;
  wasteCost: number;
  servings: number;
  nutrition: Nutrition;
  culinarySuggestion: string;
  reductionRange: [number, number];
  standardPortionOz: number;
  weightSource: WeightSource;
  costPerLb: number;
  costSource: CostSource;
  portionsPrepared: number;
  portionsServed: number;
  unservedLbs: number;
  plateWasteLbs: number;
  unservedCost: number;
  plateWasteCost: number;
}

export interface ServiceData {
  hallId: HallId;
  date: string;
  meal: Meal;
  mealsServed: number;
  items: MenuItem[];
  menuSource: MenuSource | "none";
}

export interface HallSummary {
  hall: Hall & { reporting: boolean };
  wasteLbs: number | null;
  wasteCost: number | null;
  mealsServed: number | null;
  wastePerMeal: number | null;
  topItem: MenuItem | null;
  menuSource: MenuSource | "mixed" | "none";
}

export interface TrendPoint {
  date: string;
  value: number | null;
  movingAverage?: number | null;
}

export interface Recommendation {
  id: string;
  hallId: HallId;
  date: string;
  meal: Meal;
  itemId: string;
  itemName: string;
  remainingPct: number;
  reductionRange: [number, number];
  wasteCost: number;
  title: string;
  origin: "production" | "nutrition";
  menuSource: MenuSource | "none";
  wasteLbs: number;
}

export interface HistoryEntry {
  id: string;
  recommendation: Recommendation;
  decision: Decision;
  note: string;
  timestamp: string;
  reopenedAt?: string;
}

export interface TrayReading {
  itemId: string;
  name: string;
  remainingPct: number;
  category: Category;
}

export interface Tray {
  id: string;
  sequence: number;
  readings: TrayReading[];
}

export interface SourceSummary {
  realDays: number;
  sampleDays: number;
  noneDays: number;
}

export const HALLS: Hall[] = [
  { id: "bursley", name: "Bursley" },
  { id: "south-quad", name: "South Quad" },
  { id: "east-quad", name: "East Quad" },
  { id: "mosher-jordan", name: "Mosher-Jordan" },
  { id: "markley", name: "Markley" },
  { id: "twigs", name: "Twigs" },
];

export const HALL_SCALE: Record<HallId, number> = {
  bursley: 1.05,
  "south-quad": 1.2,
  "east-quad": 0.82,
  "mosher-jordan": 0.92,
  markley: 0.88,
  twigs: 0.55,
};

export const OPERATING_DAYS = 290;

/** Share of unserved (never plated) food counted as waste. 1.0 = all of it. */
export const UNSERVED_WASTE_SHARE = 1.0;

export const round = (n: number, digits = 2) => Number(n.toFixed(digits));

export function hallName(id: HallId) {
  return HALLS.find((h) => h.id === id)?.name ?? id;
}
