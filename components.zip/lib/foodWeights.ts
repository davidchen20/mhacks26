import type { Category, WeightSource } from "./types";
import { matchesAny, wordBoundaryMatch } from "./text";

const GRAMS_PER_OZ = 28.3495;

/** Illustrative cooked-food densities used when serving size is volume-only. */
export const DENSITY_G_PER_CUP: Record<string, number> = {
  "leafy greens": 35,
  "cooked vegetables": 160,
  "cooked rice": 185,
  "cooked pasta": 140,
  "cooked grains": 160,
  oatmeal: 234,
  "yogurt/dairy": 245,
  "cooked meat": 140,
  soup: 240,
  fruit: 155,
  beans: 172,
  eggs: 202,
  sauce: 240,
};

const KEYWORD_OZ: { keywords: string[]; oz: number }[] = [
  { keywords: ["kale", "spinach", "lettuce", "spring mix", "salad"], oz: 3 },
  { keywords: ["broccoli", "green beans", "carrot", "vegetable"], oz: 3.5 },
  { keywords: ["rice", "pasta", "noodle", "quinoa"], oz: 4.5 },
  { keywords: ["oatmeal", "oats", "cereal"], oz: 6 },
  { keywords: ["chicken", "beef", "turkey", "pork", "salmon", "tofu"], oz: 4 },
  { keywords: ["egg", "eggs"], oz: 3.5 },
  { keywords: ["bacon"], oz: 1.5 },
  { keywords: ["yogurt"], oz: 5.3 },
  { keywords: ["soup"], oz: 8 },
  { keywords: ["potato", "potatoes", "mashed"], oz: 5 },
  { keywords: ["bread", "toast", "roll"], oz: 2 },
  { keywords: ["fruit", "melon", "berry", "berries", "apple", "banana"], oz: 4 },
  { keywords: ["pizza"], oz: 5 },
  { keywords: ["cheese"], oz: 1.5 },
];

const CATEGORY_DEFAULT_OZ: Record<Category, number> = {
  Protein: 4,
  Produce: 3.2,
  Grains: 4.5,
  Dairy: 5,
};

const VOLUME_UNITS: { pattern: RegExp; cups: number }[] = [
  { pattern: /(\d+(?:\.\d+)?)\s*cups?\b/i, cups: 1 },
  { pattern: /(\d+\/\d+)\s*cups?\b/i, cups: 1 },
  { pattern: /\bcups?\b/i, cups: 1 },
  { pattern: /(\d+(?:\.\d+)?)\s*fl\.?\s*oz\b/i, cups: 1 / 8 },
  { pattern: /(\d+(?:\.\d+)?)\s*fluid ounces?\b/i, cups: 1 / 8 },
  { pattern: /(\d+(?:\.\d+)?)\s*ladles?\b/i, cups: 0.5 },
  { pattern: /\bladles?\b/i, cups: 0.5 },
  { pattern: /(\d+(?:\.\d+)?)\s*scoops?\b/i, cups: 0.5 },
  { pattern: /\bscoops?\b/i, cups: 0.5 },
  { pattern: /(\d+(?:\.\d+)?)\s*tbsp\b/i, cups: 1 / 16 },
  { pattern: /(\d+(?:\.\d+)?)\s*tablespoons?\b/i, cups: 1 / 16 },
  { pattern: /(\d+(?:\.\d+)?)\s*tsp\b/i, cups: 1 / 48 },
  { pattern: /(\d+(?:\.\d+)?)\s*teaspoons?\b/i, cups: 1 / 48 },
];

function parseFraction(s: string): number | null {
  const m = s.trim().match(/^(\d+)\s*\/\s*(\d+)$/);
  if (!m) {
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }
  const a = Number(m[1]),
    b = Number(m[2]);
  return b ? a / b : null;
}

function firstNumber(pattern: RegExp, text: string): number | null {
  const m = text.match(pattern);
  if (!m) return null;
  if (!m[1]) return 1;
  return parseFraction(m[1]);
}

function parseWeightOz(serving: string): number | null {
  const gParen = serving.match(/\(([\d.]+)\s*g\)/i);
  if (gParen) return Number(gParen[1]) / GRAMS_PER_OZ;
  const g = serving.match(/([\d.]+)\s*g\b/i);
  if (g && !/mg\b/i.test(serving.slice(Math.max(0, (g.index ?? 0) - 1))))
    return Number(g[1]) / GRAMS_PER_OZ;
  const oz = serving.match(/([\d.]+)\s*oz\b/i);
  if (oz) return Number(oz[1]);
  const ounces = serving.match(/([\d.]+)\s*ounces?\b/i);
  if (ounces) return Number(ounces[1]);
  if (/\bounce\b/i.test(serving) && /\(28g\)/i.test(serving)) return 1;
  return null;
}

function parseVolumeCups(serving: string): number | null {
  const half = serving.match(/(\d+)\s+(\d+\/\d+)\s*cups?\b/i);
  if (half) {
    const whole = Number(half[1]);
    const frac = parseFraction(half[2]);
    if (frac != null) return whole + frac;
  }
  const simpleHalf = serving.match(/(\d+\/\d+)\s*cups?\b/i);
  if (simpleHalf) return parseFraction(simpleHalf[1]);
  for (const unit of VOLUME_UNITS) {
    if (unit.pattern.source.startsWith("(\\d")) {
      const n = firstNumber(unit.pattern, serving);
      if (n != null) return n * unit.cups;
    }
  }
  for (const unit of VOLUME_UNITS) {
    if (!unit.pattern.source.startsWith("(\\d") && unit.pattern.test(serving))
      return unit.cups;
  }
  return null;
}

function densityFor(itemName: string, category: Category): number {
  const n = itemName.toLowerCase();
  if (matchesAny(n, ["kale", "spinach", "lettuce", "salad", "spring mix", "greens"]))
    return DENSITY_G_PER_CUP["leafy greens"];
  if (matchesAny(n, ["soup", "chowder", "broth", "stew"]))
    return DENSITY_G_PER_CUP.soup;
  if (matchesAny(n, ["rice"])) return DENSITY_G_PER_CUP["cooked rice"];
  if (matchesAny(n, ["pasta", "noodle", "spaghetti", "macaroni"]))
    return DENSITY_G_PER_CUP["cooked pasta"];
  if (matchesAny(n, ["oatmeal", "oats"])) return DENSITY_G_PER_CUP.oatmeal;
  if (matchesAny(n, ["yogurt", "milk", "cottage cheese"]))
    return DENSITY_G_PER_CUP["yogurt/dairy"];
  if (matchesAny(n, ["chicken", "beef", "turkey", "pork", "salmon", "tofu", "meatball"]))
    return DENSITY_G_PER_CUP["cooked meat"];
  if (matchesAny(n, ["egg", "eggs"])) return DENSITY_G_PER_CUP.eggs;
  if (matchesAny(n, ["bean", "beans", "lentil", "chickpea"]))
    return DENSITY_G_PER_CUP.beans;
  if (matchesAny(n, ["fruit", "melon", "berry", "apple", "banana", "orange"]))
    return DENSITY_G_PER_CUP.fruit;
  if (category === "Produce") return DENSITY_G_PER_CUP["cooked vegetables"];
  if (category === "Grains") return DENSITY_G_PER_CUP["cooked grains"];
  if (category === "Dairy") return DENSITY_G_PER_CUP["yogurt/dairy"];
  if (category === "Protein") return DENSITY_G_PER_CUP["cooked meat"];
  return DENSITY_G_PER_CUP["cooked vegetables"];
}

function keywordOz(itemName: string): number | null {
  for (const row of KEYWORD_OZ) {
    if (row.keywords.some((k) => wordBoundaryMatch(itemName, k))) return row.oz;
  }
  return null;
}

export function gramsToOz(g: number) {
  return g / GRAMS_PER_OZ;
}

export function ozToGrams(oz: number) {
  return oz * GRAMS_PER_OZ;
}

export function standardPortionOz(
  item: { name: string; servingSize?: string | null; category: Category },
): { oz: number; source: WeightSource } {
  const serving = (item.servingSize ?? "").trim();
  if (serving) {
    const weight = parseWeightOz(serving);
    if (weight && weight > 0)
      return { oz: Number(weight.toFixed(2)), source: "serving-size" };
    const cups = parseVolumeCups(serving);
    if (cups && cups > 0) {
      const oz = gramsToOz(cups * densityFor(item.name, item.category));
      return { oz: Number(oz.toFixed(2)), source: "converted-volume" };
    }
  }
  const keyed = keywordOz(item.name);
  if (keyed != null)
    return { oz: keyed, source: "keyword-default" };
  return {
    oz: CATEGORY_DEFAULT_OZ[item.category],
    source: "category-default",
  };
}

export function weightSourceLabel(source: WeightSource) {
  switch (source) {
    case "serving-size":
      return "from serving size";
    case "converted-volume":
      return "from volume conversion";
    case "keyword-default":
      return "est. item default";
    default:
      return "est. category default";
  }
}
