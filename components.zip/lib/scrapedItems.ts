import type {
  Category,
  MenuItem,
  ScrapedItem,
} from "./types";
import { culinarySuggestion, reductionRangeFromRemaining } from "./culinary";
import { costPerLb } from "./foodCosts";
import { standardPortionOz } from "./foodWeights";
import { matchesAny, slug, wordBoundaryMatch } from "./text";

const DROP_NAME = [
  "ketchup",
  "mustard",
  "relish",
  "mayonnaise",
  "mayo",
  "hot sauce",
  "soy sauce",
  "dressing",
  "vinaigrette",
  "syrup",
  "jam",
  "jelly",
  "butter",
  "margarine",
  "cream cheese",
  "sour cream",
  "salsa",
  "coffee",
  "tea",
  "soda",
  "fountain",
  "beverage",
  "juice",
  "lemonade",
  "water",
  "ice",
  "crouton",
  "croutons",
  "parmesan packet",
];

const DROP_STATION = [
  "condiment",
  "condiments",
  "beverages",
  "beverage",
  "drink",
  "drinks",
  "topping",
  "toppings",
  "bar toppings",
];

const PROTEIN = [
  "chicken",
  "beef",
  "turkey",
  "pork",
  "ham",
  "bacon",
  "sausage",
  "salmon",
  "fish",
  "shrimp",
  "tofu",
  "tempeh",
  "meatball",
  "meatballs",
  "steak",
  "egg",
  "eggs",
  "omelet",
  "omelette",
  "scrambled",
  "frittata",
];

const PRODUCE = [
  "broccoli",
  "green beans",
  "green bean",
  "kale",
  "spinach",
  "lettuce",
  "salad",
  "carrot",
  "carrots",
  "vegetable",
  "vegetables",
  "zucchini",
  "squash",
  "pepper",
  "peppers",
  "tomato",
  "tomatoes",
  "cucumber",
  "cabbage",
  "cauliflower",
  "asparagus",
  "corn",
  "peas",
  "fruit",
  "melon",
  "berries",
  "berry",
  "apple",
  "banana",
  "orange",
  "grape",
  "grapes",
  "pineapple",
  "watermelon",
  "cantaloupe",
  "honeydew",
  "mix vegetables",
  "mixed vegetables",
  "24 carrots",
];

const GRAINS = [
  "rice",
  "pasta",
  "noodle",
  "noodles",
  "spaghetti",
  "macaroni",
  "oatmeal",
  "oats",
  "cereal",
  "bread",
  "toast",
  "roll",
  "rolls",
  "pizza",
  "potato",
  "potatoes",
  "waffle",
  "pancake",
  "pancakes",
  "quinoa",
  "stuffing",
  "biscuit",
  "grits",
  "bagel",
  "muffin",
  "tortilla",
  "couscous",
  "barley",
];

const DAIRY = ["yogurt", "cheese", "cottage cheese", "milk", "parfait"];

const PLANT_MILK = /\b(coconut|almond|oat|soy|rice|cashew)\s+milk\b/i;

export function categorizeItem(
  station: string,
  name: string,
): Category | null {
  const blob = `${station} ${name}`;
  const stationLc = station.toLowerCase();
  const nameLc = name.toLowerCase();
  if (DROP_STATION.some((s) => stationLc.includes(s))) return null;
  if (DROP_NAME.some((k) => wordBoundaryMatch(nameLc, k))) return null;
  if (/\b(cookie|brownie|cake|donut|doughnut|pastry|frosting)\b/i.test(nameLc))
    return null;

  const dairyText = nameLc.replace(PLANT_MILK, " ");
  const protein = matchesAny(blob, PROTEIN);
  const produce = matchesAny(blob, PRODUCE) || /24 carrots/i.test(station);
  const grains = matchesAny(blob, GRAINS);
  const dairy = matchesAny(dairyText, DAIRY) || matchesAny(stationLc, DAIRY);

  // Entrees win over a vegetable in the name ("chicken broccoli").
  if (protein) return "Protein";
  if (dairy && !produce && !grains) return "Dairy";
  if (grains) return "Grains";
  if (produce) return "Produce";
  if (dairy) return "Dairy";
  if (/classics|grill|halal|wild fire|signature/i.test(station) && protein)
    return "Protein";
  return null;
}

function nutritionFrom(item: ScrapedItem) {
  const hasTable =
    item.calories != null ||
    item.fiberGrams != null ||
    item.proteinGrams != null;
  if (!hasTable) return { available: false as const };
  const fiberGrams = item.fiberGrams ?? 0;
  const proteinGrams = item.proteinGrams ?? 0;
  const calories = item.calories ?? 0;
  const raw =
    calories > 0 ? ((fiberGrams * 2 + proteinGrams) / calories) * 45 : 2;
  const densityScore = Math.max(1, Math.min(5, Math.round(raw)));
  return {
    available: true as const,
    fiberGrams,
    proteinGrams,
    calories,
    densityScore,
    nutrientDensity: (densityScore >= 4 ? "high" : "moderate") as
      | "high"
      | "moderate",
  };
}

function assignIds(hallId: string, names: string[]): string[] {
  const used = new Map<string, number>();
  return names.map((name) => {
    const base = `${hallId}-${slug(name)}`;
    const n = used.get(base) ?? 0;
    used.set(base, n + 1);
    return n === 0 ? base : `${base}-${n + 1}`;
  });
}

/** Convert scraped rows to menu items. Waste simulation is applied later. */
export function itemsFromScraped(
  hallId: string,
  rows: ScrapedItem[],
  cap = 12,
): MenuItem[] {
  const categorized = rows
    .map((row) => {
      const category = categorizeItem(row.station, row.name);
      if (!category) return null;
      const weight = standardPortionOz({
        name: row.name,
        servingSize: row.servingSize,
        category,
      });
      return { row, category, weight };
    })
    .filter((x): x is NonNullable<typeof x> => x != null)
    .sort((a, b) => b.weight.oz - a.weight.oz)
    .slice(0, cap);

  const ids = assignIds(
    hallId,
    categorized.map((x) => x.row.name),
  );

  return categorized.map((x, i) => {
    const cost = costPerLb(x.row.name, x.category);
    return {
      id: ids[i],
      name: x.row.name,
      category: x.category,
      remainingPct: 0,
      wasteLbs: 0,
      wasteCost: 0,
      servings: 0,
      nutrition: nutritionFrom(x.row),
      culinarySuggestion: culinarySuggestion(x.category),
      reductionRange: reductionRangeFromRemaining(12),
      standardPortionOz: x.weight.oz,
      weightSource: x.weight.source,
      costPerLb: cost.usdPerLb,
      costSource: cost.source,
      portionsPrepared: 0,
      portionsServed: 0,
      unservedLbs: 0,
      plateWasteLbs: 0,
      unservedCost: 0,
      plateWasteCost: 0,
    };
  });
}
