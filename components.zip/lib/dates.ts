import type { Meal, OverviewMeal, Range } from "./types";

export function validDate(s: string) {
  const d = new Date(`${s}T12:00:00Z`);
  return (
    /^\d{4}-\d{2}-\d{2}$/.test(s) &&
    !Number.isNaN(+d) &&
    d.toISOString().slice(0, 10) === s
  );
}

/** Campus "today" in America/Detroit, optionally overridden for demos. */
export function getToday(now = new Date()): string {
  const override =
    typeof process !== "undefined"
      ? process.env.NEXT_PUBLIC_DEMO_DATE
      : undefined;
  if (override && validDate(override)) return override;
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "America/Detroit",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(now);
  const year = parts.find((p) => p.type === "year")?.value;
  const month = parts.find((p) => p.type === "month")?.value;
  const day = parts.find((p) => p.type === "day")?.value;
  return `${year}-${month}-${day}`;
}

export function addDays(date: string, n: number) {
  const d = new Date(`${date}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() + n);
  return d.toISOString().slice(0, 10);
}

export function weekdayUtc(date: string) {
  return new Date(`${date}T12:00:00Z`).getUTCDay();
}

export function isWeekend(date: string) {
  const d = weekdayUtc(date);
  return d === 0 || d === 6;
}

export function mealsForDate(date: string): Meal[] {
  return isWeekend(date)
    ? ["brunch", "dinner"]
    : ["breakfast", "lunch", "dinner"];
}

export function datesForRange(
  range: Range,
  today = getToday(),
  offset = 0,
): string[] {
  const end = addDays(today, offset - (range === "yesterday" ? 1 : 0));
  return range === "week"
    ? Array.from({ length: 7 }, (_, i) => addDays(end, i - 6))
    : [end];
}

export function mealOptionsForDates(dates: string[]): OverviewMeal[] {
  if (dates.length === 1) {
    return isWeekend(dates[0])
      ? ["all", "brunch", "dinner"]
      : ["all", "breakfast", "lunch", "dinner"];
  }
  return ["all", "breakfast", "lunch", "brunch", "dinner"];
}

export function mealValidForDates(meal: OverviewMeal, dates: string[]) {
  return mealOptionsForDates(dates).includes(meal);
}

export function compareDate(a: string, b: string) {
  return a === b ? 0 : a < b ? -1 : 1;
}
